Welcome to Nextcord's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api.rst
   internals.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
