API Reference
==============
.. autoclass:: nextcord.Client
    :members:
.. autoclass:: nextcord.type_sheet.TypeSheet
    :members:
.. automodule:: nextcord.flags
    :exclude-members: flags
    :members:
    :undoc-members:
