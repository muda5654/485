Internals API Reference
========================
.. currentmodule:: nextcord

.. warning::
    This is probably not what you are looking for!
    This is for the internals of Nextcord and for people who want to write custom implementations of some of our modules

.. automodule:: nextcord.core.http
   :members:
.. automodule:: nextcord.core.gateway
   :members:

Protocols
---------
.. automodule:: nextcord.core.protocols.http
    :members:
.. automodule:: nextcord.core.gateway.protocols
    :members:

