# Nextcord V3

!!! Nextcord V3 as a separate project is discontinued. Continued development of a similar project can be found at https://github.com/nextsnake/nextcore

---

A fast :rocket: modular Discord API wrapper written for python

## Installation

`pip install git+https://github.com/nextcord/nextcord-v3`

## Development Status

V3 is currently in private development, which is why this is not updated. Will be updated soontm
